﻿using System; 
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tqrguil1_csharp
{
    class Program
    {
        static int Main(string[] args)

        {
            int[] A = new int[20];
            int[] B = new int[20];
            int[] C = new int[20];
            Random rnd = new Random();

            for (int i=0;i<20;i++)
            {
                A[i] = rnd.Next(18, 122);
            }
            for (int i = 0; i < 20; i++)
            {
                B[i] = rnd.Next(18, 122);
            }
            for (int i = 0; i < 20; i++)
            {
                if (A[i]>B[i])
                   C[i] = A[i] - B[i];
                else
                    C[i] = B[i] - A[i];
            }
            Console.WriteLine("A");
            foreach (var item in A)
               Console.WriteLine(item);

            Console.WriteLine("B");
            foreach (var item in B)
                Console.WriteLine(item);

            Console.WriteLine("C");
            foreach (var item in C)
                Console.WriteLine(item);

            return 0;
        }

    }
}

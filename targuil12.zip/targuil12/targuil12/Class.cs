﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace targuil12
{
    class Class
    {

        public static bool[,] calendar = new bool[31, 12];// on a enlever 1 a day et month pour que sa rentre dans la matrice


        public void Help()
        {
            Console.WriteLine("jesuislahelp");

            for (int i = 0; i < 31; i++)
                for (int j = 0; j < 12; j++)
                {
                    Console.WriteLine("jesuislafor");
                    calendar[i, j] = false;
                    Console.WriteLine("calandar");
                }
        }




        public bool A(string day, string month, string timeStaying)
        {

            int myday = int.Parse(day) - 1;
            int myfirstday = myday;
            int mymonth = int.Parse(month) - 1;
            int myfirstmonth = mymonth;
            int mytime = int.Parse(timeStaying) - 1;




            if (calendar[myday, mymonth] == false)
            {
                Console.WriteLine("jesuisla");
                for (int i = 0; i < mytime; i++)
                {
                    Console.WriteLine("jesuislaboucle");
                    myday++;
                    if (myday % 31 == 1)
                    {
                        mymonth++;
                        myday = 0;
                        if (mymonth % 12 == 1)
                            mymonth = 0;
                    }
                    Console.WriteLine(calendar[myday, mymonth]);
                    if (calendar[myday, mymonth] == true)
                        return true;

                }

                myday = myfirstday;
                mymonth = myfirstmonth;
                calendar[myday, mymonth] = true;

                for (int i = 0; i < mytime - 1; i++)
                {
                    myday++;
                    if (myday % 31 == 1)
                    {
                        mymonth++;
                        myday = 1;
                        if (mymonth % 12 == 1)
                            mymonth = 1;

                    }

                    calendar[myday, mymonth] = true;
                    Console.WriteLine();
                }

                return false;
            }
            else
            {
                Console.WriteLine("jesuislaelse");
                return true;
            }








        }


        static void B()
        {
           

            if (calendar[0,0]==true)
                Console.WriteLine(1 +"." + 1);
            for (int m = 0; m < 12; m++)
                for (int d = 1; d < 31; d++)
                {
                    if(d==0 && m!=0)
                    {
                        if ((calendar[30, m - 1] == true && calendar[d, m] == false) || (calendar[30, m - 1] == false && calendar[d, m] == true))
                            Console.WriteLine(d++ + "." + m++);
                    }
                    if (calendar[d, m])
                        if ((calendar[d-1, m] == true && calendar[d, m] == false) || (calendar[d-1, m] == false && calendar[d, m] == true))
                        {
                            Console.WriteLine(d++ + "." + m++);
                        }

                }





        }

        static void C()
        {
            int compt=0;
            for(int m = 0; m < 12; m++)
                for (int d = 0; d < 31; d++)
            {
                    if (calendar[d, m] == true)
                        compt++;
            }

            int pourcent = compt / 372 * 100;
            Console.WriteLine("there's " +compt+"days unavailables wich is" +pourcent+"% days of the year");
    }


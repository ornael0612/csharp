﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace targuil12
{
    class Program
    {
        static void Main(string[] args)
    {
        Class T = new Class();
        T.Help();


            string str;
        do
        {
                Console.WriteLine("this is the menu:\n A: give me your date vacation and the time you will stay\n B: the date unavailable \n C: stat \n D: exit");
                str = Console.ReadLine();
                switch (str)
            {

                case "A":
                case "a":
                    Console.WriteLine("arriving day :");

                    string day = Console.ReadLine();
                    Console.WriteLine("arriving month :");
                    string month = Console.ReadLine();

                    Console.WriteLine("time staying :");
                    string timeStaying = Console.ReadLine();
                    if (T.A(day, month, timeStaying)==true)
                        Console.WriteLine("sorry there is no avaibilities for your date");
                    else
                        Console.WriteLine("good vacations, thanks to have order with us :p");
                    break;


                case "B":
                case "b":
                    break;
                case "C":
                case "c":
                    break;
                case "D":
                case "d":
                    break;
                default:
                    Console.WriteLine("Error");
                    break;
            }
               
            } while (str != "D");









    }
}
}

